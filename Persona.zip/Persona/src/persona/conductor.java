
package persona;

public class conductor extends Personaa {
    
Integer licencia;
Integer deuda;
        
    public boolean mayor(){
        if (edad >= 18){
            return true;  
        }else{
            return false;
    }
}
}
