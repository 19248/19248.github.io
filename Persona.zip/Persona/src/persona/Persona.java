
package persona;


public class Persona {

    public static void main(String[] args) {
        conductor con1 = new conductor();
        con1.nombre = "Juan";
        con1.nombre2 = "Jose";
        con1.apellido = "Martinez";
        con1.apellido2 = "Escoces";
        con1.setEdad(18);

        if (con1.mayor()) {
            System.out.println(con1.completo() + " es mayor de edad");
        } else {
            System.out.println(con1.completo() + " es menor de edad");
        }
    }
        
    
    
}
