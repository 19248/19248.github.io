
package persona;


public class Personaa {
    String nombre;
    String nombre2;
    String apellido;
    String apellido2;
    protected Integer edad;
    
    public String completo(){
        return nombre + nombre2 + apellido + apellido2;
    }  
    public void setEdad(Integer eda){
        edad = eda;
    }    
}

